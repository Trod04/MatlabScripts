function [ MeterConfig ] = MeterParameterConfig()

%Info
%----

MeterConfig.Size = 8;
MeterConfig.MeterType = 68;
MeterConfig.ParInfo = 'TCC 5D - CPA - 5D parameter config';


%PathLenghts, angles & ID
%----------------
MeterConfig.ID = 0.19;

MeterConfig.PL(1) = 0.55806;
MeterConfig.PL(2) = 0.17541;
MeterConfig.PL(3) = 0.17541;
MeterConfig.PL(4) = 0.24803;
MeterConfig.PL(5) = 0.24803;
MeterConfig.PL(6) = 0.17541;
MeterConfig.PL(7) = 0.17541;
MeterConfig.PL(8) = 0.55806;

MeterConfig.Angle(1) = 62.2;
MeterConfig.Angle(2) = 50;
MeterConfig.Angle(3) = 50;
MeterConfig.Angle(4) = 50;
MeterConfig.Angle(5) = 50;
MeterConfig.Angle(6) = 50;
MeterConfig.Angle(7) = 50;
MeterConfig.Angle(8) = 62.2;

%Dens/Visc
%-------------
MeterConfig.Density = 42.5;
MeterConfig.Visc = 0.0000130;

%Reynolds Pars
%-------------

%Type A
MeterConfig.ReynoldsType(1).Par(1) = 4000;
MeterConfig.ReynoldsType(1).Par(2) = 25;
MeterConfig.ReynoldsType(1).Par(3) = 0.85;
MeterConfig.ReynoldsType(1).Par(4) = 1.07;
MeterConfig.ReynoldsType(1).Par(5) = 0.3;
MeterConfig.ReynoldsType(1).Par(6) = 0;


%Type B
MeterConfig.ReynoldsType(2).Par(1) = 1;
MeterConfig.ReynoldsType(2).Par(2) = 1;
MeterConfig.ReynoldsType(2).Par(3) = 1;
MeterConfig.ReynoldsType(2).Par(4) = 1;
MeterConfig.ReynoldsType(2).Par(5) = 0;
MeterConfig.ReynoldsType(2).Par(6) = 0;

%Type C
MeterConfig.ReynoldsType(3).Par(1) = 1;
MeterConfig.ReynoldsType(3).Par(2) = 1;
MeterConfig.ReynoldsType(3).Par(3) = 1;
MeterConfig.ReynoldsType(3).Par(4) = 1;
MeterConfig.ReynoldsType(3).Par(5) = 0;
MeterConfig.ReynoldsType(3).Par(6) = 0;

%Type D
MeterConfig.ReynoldsType(4).Par(1) = 4000;
MeterConfig.ReynoldsType(4).Par(2) = 25;
MeterConfig.ReynoldsType(4).Par(3) = 0.85;
MeterConfig.ReynoldsType(4).Par(4) = 1.07;
MeterConfig.ReynoldsType(4).Par(5) = 0.3;
MeterConfig.ReynoldsType(4).Par(6) = 0;

%Pathtype weight
%---------------

MeterConfig.WeightType(1) = 0;
MeterConfig.WeightType(2) = 1;
MeterConfig.WeightType(3) = 0;
MeterConfig.WeightType(4) = 0;

end

